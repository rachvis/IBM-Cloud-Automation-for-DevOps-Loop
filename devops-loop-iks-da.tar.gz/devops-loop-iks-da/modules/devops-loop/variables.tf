########################################################################################################################
# Input Variables — DevOps Loop Module
########################################################################################################################

variable "prefix" {
  type        = string
  nullable    = true
  description = "Resource name prefix."
  default     = null
}

variable "namespace" {
  type        = string
  description = "Kubernetes namespace for DevOps Loop."
  default     = "devops-loop"
}

variable "chart_version" {
  type        = string
  description = "OCI Helm chart version for hcl-devops-loop."
}

variable "domain" {
  type        = string
  description = "Custom domain for the DevOps Loop deployment."
}

variable "license_server" {
  type        = string
  description = "HCL Rational License Key Server address (e.g. @license.example.com)."
}

variable "tls_certificate" {
  type        = string
  sensitive   = true
  description = "PEM-encoded TLS certificate."
}

variable "tls_private_key" {
  type        = string
  sensitive   = true
  description = "PEM-encoded TLS private key."
}

variable "hcl_harbor_username" {
  type        = string
  description = "HCL Harbor username for hclcr.io."
}

variable "hcl_harbor_cli_secret" {
  type        = string
  sensitive   = true
  description = "HCL Harbor CLI secret / entitlement key."
}

variable "rwo_storage_class" {
  type        = string
  description = "ReadWriteOnce storage class."
  default     = "ibmc-block-gold"
}

variable "rwx_storage_class" {
  type        = string
  description = "ReadWriteMany storage class."
  default     = "ibmc-file-gold-gid"
}

variable "emissary_chart_version" {
  type        = string
  description = "Helm chart version for Emissary-ingress."
  default     = "3.9.1"
}

variable "smtp_host" {
  type        = string
  description = "SMTP server hostname. Empty string disables SMTP."
  default     = ""
}

variable "smtp_port" {
  type        = number
  description = "SMTP server port."
  default     = 587
}

variable "smtp_from_address" {
  type        = string
  description = "SMTP from address."
  default     = ""
}

variable "smtp_username" {
  type        = string
  description = "SMTP username."
  default     = ""
}

variable "smtp_password" {
  type        = string
  sensitive   = true
  description = "SMTP password."
  default     = ""
}

variable "enable_plan" {
  type    = bool
  default = true
}

variable "enable_code" {
  type    = bool
  default = true
}

variable "enable_control" {
  type    = bool
  default = true
}

variable "enable_build" {
  type    = bool
  default = true
}

variable "enable_test" {
  type    = bool
  default = true
}

variable "enable_release" {
  type    = bool
  default = true
}

variable "enable_deploy" {
  type    = bool
  default = true
}

variable "enable_measure" {
  type    = bool
  default = true
}
