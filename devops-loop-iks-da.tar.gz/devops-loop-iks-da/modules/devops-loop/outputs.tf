########################################################################################################################
# Outputs — DevOps Loop Module
########################################################################################################################

output "emissary_namespace" {
  description = "The namespace where Emissary-ingress is deployed."
  value       = kubernetes_namespace.emissary.metadata[0].name
}

output "devops_loop_namespace" {
  description = "The namespace where DevOps Loop is deployed."
  value       = kubernetes_namespace.devops_loop.metadata[0].name
}

output "helm_release_status" {
  description = "Status of the DevOps Loop Helm release."
  value       = helm_release.devops_loop.status
}

output "tls_secret_name" {
  description = "Name of the TLS Kubernetes secret."
  value       = kubernetes_secret.tls.metadata[0].name
}
