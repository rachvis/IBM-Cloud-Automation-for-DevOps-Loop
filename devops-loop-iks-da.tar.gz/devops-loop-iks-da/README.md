# IBM DevOps Loop on IBM Cloud Kubernetes Service

[![IBM Cloud Deployable Architecture](https://img.shields.io/badge/IBM%20Cloud-Deployable%20Architecture-blue)](https://cloud.ibm.com/catalog)

A [Deployable Architecture](https://cloud.ibm.com/docs/secure-enterprise?topic=secure-enterprise-understand-module-da) that automates the end-to-end deployment of [IBM DevOps Loop](https://www.ibm.com/docs/en/devops-loop) on [IBM Cloud Kubernetes Service (IKS)](https://cloud.ibm.com/docs/containers).

## Overview

IBM DevOps Loop unifies all eight phases of the software delivery lifecycle into a single platform:

| Capability | Description |
|------------|-------------|
| **Plan** | Project tracking, issue management, and backlog |
| **Code** | Browser-based IDE — no local setup required |
| **Control** | Source control management and governance |
| **Build** | CI pipelines and build automation |
| **Test** | Test management, execution, and reporting |
| **Release** | Release orchestration and approval workflows |
| **Deploy** | Deployment automation across environments |
| **Measure** | Real-time dashboards and delivery analytics |
| **Loop Genie** | AI assistant powered by IBM watsonx |

## Architecture

![Architecture diagram](./reference-architectures/diagram-self-managed.svg)

The Self-Managed flavor provisions:

- **VPC and Subnet** — single-zone `/24` subnet (optional, skipped when `existing_vpc_id` is provided)
- **IKS Cluster** — 3 × `bx2.8x32` worker nodes (8 vCPU / 32 GB RAM) (optional, skipped when `existing_cluster_id` is provided)
- **Emissary-ingress** — Ambassador Edge Stack API gateway in the `emissary` namespace, with an IBM Cloud Network Load Balancer exposing ports 80, 443, 7919, 7920, and 9022
- **DevOps Loop** — OCI Helm chart `oci://hclcr.io/devops-automation-helm/hcl-devops-loop` deployed into the `devops-loop` namespace
- **Secrets** — Kubernetes TLS secret and HCL Harbor image-pull secret

### Repository structure

```
.
├── ibm_catalog.json                  # IBM Cloud Private Catalog manifest
├── main.tf                           # Root module — VPC, IKS, module calls
├── variables.tf                      # Root module inputs
├── outputs.tf                        # Root module outputs
├── version.tf                        # Provider version constraints
├── modules/
│   └── devops-loop/                  # Child module — Kubernetes + Helm resources
│       ├── main.tf
│       ├── variables.tf
│       ├── outputs.tf
│       └── version.tf
├── solutions/
│   └── self-managed/                 # DA flavor — thin wrapper + provider config
│       ├── main.tf
│       ├── provider.tf
│       ├── variables.tf
│       ├── outputs.tf
│       ├── version.tf
│       └── catalogValidationValues.json.template
└── reference-architectures/
    └── diagram-self-managed.svg
```

## Prerequisites

Before deploying, ensure you have:

1. **IBM Cloud API key** with the IAM permissions listed in `ibm_catalog.json`
2. **HCL Harbor credentials** — username and CLI secret from [hclcr.io](https://hclcr.io)
3. **HCL License Server** — a running HCL Rational License Key Server in format `@<hostname-or-ip>`
4. **Custom domain** — registered in IKS Ingress Domains and set as the default domain for the cluster
5. **TLS certificate** — PEM-encoded certificate issued by a trusted CA for your domain (self-signed certificates require additional cluster configuration)

## Deployment via IBM Cloud Private Catalog

1. Push this repository to GitHub and create a release tag (e.g. `v1.0.3`)
2. In IBM Cloud, navigate to **Manage → Catalogs → Private catalogs**
3. Create a new catalog and click **Add product**
4. Select **Deployable architecture** and paste the archive URL:
   ```
   https://github.com/YOUR_ORG/devops-loop-iks-da/archive/refs/tags/v1.0.3.tar.gz
   ```
5. Select the **Self-Managed** flavor and complete onboarding
6. Deploy via **IBM Cloud Projects** or **Schematics**

## Local Development

```bash
# Authenticate
export IBMCLOUD_API_KEY="<your-api-key>"

# Initialise
cd solutions/self-managed
terraform init

# Plan
terraform plan -var-file="terraform.tfvars"

# Apply
terraform apply -var-file="terraform.tfvars"
```

Example `terraform.tfvars`:

```hcl
region                = "us-south"
prefix                = "dev"
devops_loop_domain    = "devops.example.com"
license_server        = "@license.example.com"
hcl_harbor_username   = "your-harbor-username"
hcl_harbor_cli_secret = "your-harbor-cli-secret"
tls_certificate       = file("cert.pem")
tls_private_key       = file("key.pem")
```

## IAM Permissions

| Service | Role | Purpose |
|---------|------|---------|
| IBM Kubernetes Service | Manager, Administrator | Create/manage IKS cluster and Kubernetes resources |
| VPC Infrastructure | Administrator | Create/manage VPC and subnet |
| IAM Identity | Administrator, UserApiKeyCreator | Create the cluster service API key |
| Resource Controller | Editor | Create resource instances |

## Inputs

See [`solutions/self-managed/variables.tf`](solutions/self-managed/variables.tf) for the full list of input variables. Key required inputs:

| Variable | Description |
|----------|-------------|
| `ibmcloud_api_key` | IBM Cloud API key |
| `devops_loop_domain` | Custom domain for DevOps Loop |
| `license_server` | HCL License Server address (e.g. `@license.example.com`) |
| `hcl_harbor_username` | HCL Harbor username |
| `hcl_harbor_cli_secret` | HCL Harbor CLI secret |
| `tls_certificate` | PEM-encoded TLS certificate |
| `tls_private_key` | PEM-encoded TLS private key |

## Outputs

| Output | Description |
|--------|-------------|
| `cluster_id` | IKS cluster ID |
| `vpc_id` | VPC ID |
| `devops_loop_url` | HTTPS URL for the DevOps Loop dashboard |
| `devops_loop_namespace` | Kubernetes namespace for DevOps Loop |
| `emissary_namespace` | Kubernetes namespace for Emissary-ingress |
| `enabled_capabilities` | Map of capability names to enabled status |

## Important Notes

- **Worker node size**: `bx2.8x32` (8 vCPU / 32 GB RAM) is the minimum recommended flavor. Smaller nodes may cause pods to be evicted.
- **RWX storage is required**: Several DevOps Loop components share persistent volumes. Ensure `ibmc-file-gold-gid` (or equivalent RWX class) is available in your cluster.
- **Emissary-ingress is mandatory**: DevOps Loop's WebSocket and SSH connections require Emissary-ingress; standard Kubernetes Ingress is not supported.
- **First login**: After deployment, navigate to `https://<devops_loop_domain>` and create the initial admin teamspace before inviting users.

## License

Apache License 2.0 — see [LICENSE](LICENSE).
