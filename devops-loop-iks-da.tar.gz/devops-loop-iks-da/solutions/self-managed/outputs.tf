########################################################################################################################
# Outputs — Self-Managed Solution
########################################################################################################################

output "cluster_id" {
  description = "The ID of the IKS cluster (provisioned or existing)."
  value       = module.devops_loop_on_iks.cluster_id
}

output "vpc_id" {
  description = "The ID of the VPC (provisioned or existing)."
  value       = module.devops_loop_on_iks.vpc_id
}

output "resource_group_id" {
  description = "The ID of the resource group used."
  value       = module.devops_loop_on_iks.resource_group_id
}

output "devops_loop_url" {
  description = "The HTTPS URL to access the DevOps Loop dashboard."
  value       = module.devops_loop_on_iks.devops_loop_url
}

output "devops_loop_namespace" {
  description = "The Kubernetes namespace where DevOps Loop is deployed."
  value       = module.devops_loop_on_iks.devops_loop_namespace
}

output "emissary_namespace" {
  description = "The Kubernetes namespace where Emissary-ingress is deployed."
  value       = module.devops_loop_on_iks.emissary_namespace
}

output "enabled_capabilities" {
  description = "Map of DevOps Loop capabilities and their enabled status."
  value       = module.devops_loop_on_iks.enabled_capabilities
}
