########################################################################################################################
# Resource Group
########################################################################################################################

module "resource_group" {
  source                       = "terraform-ibm-modules/resource-group/ibm"
  version                      = "1.4.7"
  existing_resource_group_name = var.existing_resource_group_name
}

########################################################################################################################
# Locals
########################################################################################################################

locals {
  prefix       = var.prefix != null ? trimspace(var.prefix) != "" ? "${var.prefix}-" : "" : ""
  cluster_id   = var.existing_cluster_id != null ? var.existing_cluster_id : ibm_container_vpc_cluster.devops_loop[0].id
  vpc_id       = var.existing_vpc_id != null ? data.ibm_is_vpc.existing[0].id : ibm_is_vpc.devops_loop[0].id
  subnet_id    = var.existing_subnet_id != null ? data.ibm_is_subnet.existing[0].id : ibm_is_subnet.devops_loop[0].id
  tags         = concat(var.resource_tags, ["devops-loop", "iks"])
}

########################################################################################################################
# VPC (conditional — skipped when existing_vpc_id is provided)
########################################################################################################################

resource "ibm_is_vpc" "devops_loop" {
  count          = var.existing_vpc_id == null ? 1 : 0
  name           = "${local.prefix}vpc"
  resource_group = module.resource_group.resource_group_id
  tags           = local.tags
}

data "ibm_is_vpc" "existing" {
  count      = var.existing_vpc_id != null ? 1 : 0
  identifier = var.existing_vpc_id
}

########################################################################################################################
# Subnet (conditional)
########################################################################################################################

data "ibm_is_zones" "regional" {
  region = var.region
}

resource "ibm_is_subnet" "devops_loop" {
  count                    = var.existing_subnet_id == null ? 1 : 0
  name                     = "${local.prefix}subnet-1"
  vpc                      = local.vpc_id
  zone                     = data.ibm_is_zones.regional.zones[0]
  resource_group           = module.resource_group.resource_group_id
  total_ipv4_address_count = 256
  tags                     = local.tags
}

data "ibm_is_subnet" "existing" {
  count      = var.existing_subnet_id != null ? 1 : 0
  identifier = var.existing_subnet_id
}

########################################################################################################################
# IKS Cluster (conditional — skipped when existing_cluster_id is provided)
########################################################################################################################

resource "ibm_container_vpc_cluster" "devops_loop" {
  count             = var.existing_cluster_id == null ? 1 : 0
  name              = "${local.prefix}cluster"
  vpc_id            = local.vpc_id
  flavor            = var.worker_flavor
  worker_count      = var.worker_count
  kube_version      = var.kubernetes_version
  resource_group_id = module.resource_group.resource_group_id
  tags              = local.tags

  zones {
    subnet_id = local.subnet_id
    name      = data.ibm_is_zones.regional.zones[0]
  }
}

# Allow time for cluster worker nodes to fully initialise before Helm operations
resource "time_sleep" "wait_for_cluster" {
  count           = var.existing_cluster_id == null ? 1 : 0
  create_duration = "300s"
  depends_on      = [ibm_container_vpc_cluster.devops_loop]
}

########################################################################################################################
# DevOps Loop Helm Deployment (via child module)
########################################################################################################################

module "devops_loop" {
  source = "./modules/devops-loop"

  prefix            = var.prefix
  namespace         = var.devops_loop_namespace
  chart_version     = var.devops_loop_chart_version
  domain            = var.devops_loop_domain
  license_server    = var.license_server
  tls_certificate   = var.tls_certificate
  tls_private_key   = var.tls_private_key

  hcl_harbor_username   = var.hcl_harbor_username
  hcl_harbor_cli_secret = var.hcl_harbor_cli_secret

  smtp_host         = var.smtp_host
  smtp_port         = var.smtp_port
  smtp_from_address = var.smtp_from_address
  smtp_username     = var.smtp_username
  smtp_password     = var.smtp_password

  rwo_storage_class = var.rwo_storage_class
  rwx_storage_class = var.rwx_storage_class

  emissary_chart_version = var.emissary_chart_version

  enable_plan    = var.enable_plan
  enable_code    = var.enable_code
  enable_control = var.enable_control
  enable_build   = var.enable_build
  enable_test    = var.enable_test
  enable_release = var.enable_release
  enable_deploy  = var.enable_deploy
  enable_measure = var.enable_measure

  depends_on = [
    ibm_container_vpc_cluster.devops_loop,
    time_sleep.wait_for_cluster
  ]
}
