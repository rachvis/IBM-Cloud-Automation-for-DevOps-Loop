########################################################################################################################
# Outputs
########################################################################################################################

output "cluster_id" {
  description = "The ID of the IKS cluster (provisioned or existing)."
  value       = local.cluster_id
}

output "vpc_id" {
  description = "The ID of the VPC (provisioned or existing)."
  value       = local.vpc_id
}

output "subnet_id" {
  description = "The ID of the subnet (provisioned or existing)."
  value       = local.subnet_id
}

output "resource_group_id" {
  description = "The ID of the resource group used."
  value       = module.resource_group.resource_group_id
}

output "devops_loop_namespace" {
  description = "The Kubernetes namespace where DevOps Loop is deployed."
  value       = var.devops_loop_namespace
}

output "devops_loop_url" {
  description = "The HTTPS URL to access the DevOps Loop dashboard."
  value       = "https://${var.devops_loop_domain}"
}

output "enabled_capabilities" {
  description = "Map of DevOps Loop capabilities and their enabled status."
  value = {
    plan    = var.enable_plan
    code    = var.enable_code
    control = var.enable_control
    build   = var.enable_build
    test    = var.enable_test
    release = var.enable_release
    deploy  = var.enable_deploy
    measure = var.enable_measure
  }
}

output "emissary_namespace" {
  description = "The Kubernetes namespace where Emissary-ingress is deployed."
  value       = module.devops_loop.emissary_namespace
}
