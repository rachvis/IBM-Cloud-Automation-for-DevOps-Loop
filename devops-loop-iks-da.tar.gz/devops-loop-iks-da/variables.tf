########################################################################################################################
# Input Variables
########################################################################################################################

variable "region" {
  type        = string
  description = "The IBM Cloud region where all resources will be deployed."
  default     = "us-south"
}

variable "prefix" {
  type        = string
  nullable    = true
  description = "A prefix to apply to all resources created by this solution (e.g. `dev`, `prod`). To use no prefix set this to null or an empty string. [Learn more](https://terraform-ibm-modules.github.io/documentation/#/prefix.md)."
  default     = "dl"

  validation {
    condition = (var.prefix == null || var.prefix == "" ? true :
      alltrue([
        can(regex("^[a-z][-a-z0-9]*[a-z0-9]$", var.prefix)),
        length(regexall("--", var.prefix)) == 0
      ])
    )
    error_message = "Prefix must begin with a lowercase letter and may only contain lowercase letters, digits, and hyphens. It must not end with a hyphen or contain consecutive hyphens."
  }

  validation {
    condition     = var.prefix == null || var.prefix == "" ? true : length(var.prefix) <= 16
    error_message = "Prefix must not exceed 16 characters."
  }
}

variable "existing_resource_group_name" {
  type        = string
  description = "The name of an existing resource group in which to provision resources. If not provided the default resource group is used."
  default     = null
}

variable "resource_tags" {
  type        = list(string)
  description = "Optional list of tags to add to all created resources."
  default     = []
}

########################################################################################################################
# VPC / Networking
########################################################################################################################

variable "existing_vpc_id" {
  type        = string
  description = "The ID of an existing VPC to deploy into. If null, a new VPC is created."
  default     = null
}

variable "existing_subnet_id" {
  type        = string
  description = "The ID of an existing subnet to use. If null, a new subnet is created in the VPC."
  default     = null
}

########################################################################################################################
# IKS Cluster
########################################################################################################################

variable "existing_cluster_id" {
  type        = string
  description = "The ID of an existing IKS cluster. If null, a new cluster is provisioned."
  default     = null
}

variable "kubernetes_version" {
  type        = string
  description = "The Kubernetes version for the new IKS cluster. Ignored when existing_cluster_id is set."
  default     = "1.30"
}

variable "worker_flavor" {
  type        = string
  description = "The worker node machine type. Minimum recommended: bx2.8x32 (8 vCPU / 32 GB RAM)."
  default     = "bx2.8x32"
}

variable "worker_count" {
  type        = number
  description = "Number of worker nodes per zone."
  default     = 3
}

########################################################################################################################
# DevOps Loop — Application
########################################################################################################################

variable "devops_loop_namespace" {
  type        = string
  description = "The Kubernetes namespace into which DevOps Loop is deployed."
  default     = "devops-loop"
}

variable "devops_loop_chart_version" {
  type        = string
  description = "The OCI Helm chart version for HCL DevOps Loop (e.g. `1.0.3`)."
  default     = "1.0.3"
}

variable "devops_loop_domain" {
  type        = string
  description = "The custom domain used to access DevOps Loop (e.g. `devops.example.com`). Must be registered in IKS Ingress Domains."
}

variable "license_server" {
  type        = string
  description = "The HCL Rational License Key Server address in the format `@<hostname-or-ip>` (e.g. `@license.example.com`)."
}

########################################################################################################################
# HCL Harbor Registry
########################################################################################################################

variable "hcl_harbor_username" {
  type        = string
  description = "Your HCL Harbor (hclcr.io) username for pulling DevOps Loop images."
}

variable "hcl_harbor_cli_secret" {
  type        = string
  sensitive   = true
  description = "Your HCL Harbor CLI secret / entitlement key for authenticating to hclcr.io."
}

########################################################################################################################
# TLS
########################################################################################################################

variable "tls_certificate" {
  type        = string
  sensitive   = true
  description = "PEM-encoded TLS certificate for the DevOps Loop domain. Must be issued by a trusted CA."
}

variable "tls_private_key" {
  type        = string
  sensitive   = true
  description = "PEM-encoded private key corresponding to tls_certificate."
}

########################################################################################################################
# Storage
########################################################################################################################

variable "rwo_storage_class" {
  type        = string
  description = "ReadWriteOnce storage class for stateful workloads (databases)."
  default     = "ibmc-block-gold"
}

variable "rwx_storage_class" {
  type        = string
  description = "ReadWriteMany storage class for shared volumes."
  default     = "ibmc-file-gold-gid"
}

########################################################################################################################
# Emissary-ingress (mandatory API gateway)
########################################################################################################################

variable "emissary_chart_version" {
  type        = string
  description = "Helm chart version for Emissary-ingress (Ambassador Edge Stack)."
  default     = "3.9.1"
}

########################################################################################################################
# SMTP (optional — enables email notifications)
########################################################################################################################

variable "smtp_host" {
  type        = string
  description = "SMTP server hostname. Leave empty to disable email notifications."
  default     = ""
}

variable "smtp_port" {
  type        = number
  description = "SMTP server port (e.g. 587 for STARTTLS, 465 for SSL)."
  default     = 587
}

variable "smtp_from_address" {
  type        = string
  description = "The 'From' email address for DevOps Loop notifications."
  default     = ""
}

variable "smtp_username" {
  type        = string
  description = "SMTP authentication username."
  default     = ""
}

variable "smtp_password" {
  type        = string
  sensitive   = true
  description = "SMTP authentication password."
  default     = ""
}

########################################################################################################################
# Capability toggles
########################################################################################################################

variable "enable_plan" {
  type        = bool
  description = "Enable the Plan capability (project tracking and backlog management)."
  default     = true
}

variable "enable_code" {
  type        = bool
  description = "Enable the Code capability (browser-based IDE)."
  default     = true
}

variable "enable_control" {
  type        = bool
  description = "Enable the Control capability (source control management and governance)."
  default     = true
}

variable "enable_build" {
  type        = bool
  description = "Enable the Build capability (CI pipelines and build automation)."
  default     = true
}

variable "enable_test" {
  type        = bool
  description = "Enable the Test capability (test management and execution)."
  default     = true
}

variable "enable_release" {
  type        = bool
  description = "Enable the Release capability (release orchestration and approval workflows)."
  default     = true
}

variable "enable_deploy" {
  type        = bool
  description = "Enable the Deploy capability (deployment automation)."
  default     = true
}

variable "enable_measure" {
  type        = bool
  description = "Enable the Measure capability (dashboards and delivery analytics)."
  default     = true
}
