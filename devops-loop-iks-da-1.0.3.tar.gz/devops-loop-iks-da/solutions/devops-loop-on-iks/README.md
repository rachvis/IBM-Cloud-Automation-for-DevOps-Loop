# IBM DevOps Loop on IKS — Solution

This Terraform solution deploys IBM DevOps Loop on IBM Cloud Kubernetes Service.

## Installation Sequence

The Terraform performs the following steps in order:

1. **VPC + Subnet** — created unless `use_existing_vpc = true`
2. **IKS Cluster** — created unless `existing_cluster_id` is set; waits for `IngressReady`
3. **Kubernetes Namespaces** — `emissary` and `devops-loop`
4. **Emissary CRDs** — applied via Helm before the ingress controller
5. **Emissary-ingress** — Ambassador Edge Stack with all required ports
6. **HCL Harbor Pull Secret** — `hcl-entitlement-key` in the devops-loop namespace
7. **TLS Secret** — certificate and key from your IBM Secrets Manager integration
8. **DevOps Loop Helm Release** — from `oci://hclcr.io/devops-automation-helm/hcl-devops-loop`

## Verifying the Installation

```bash
# 1. Configure kubectl
ibmcloud ks cluster config --cluster <cluster-id>

# 2. Check all DevOps Loop pods are Running
kubectl get pods -n devops-loop

# 3. Check Emissary pods are Running
kubectl get pods -n emissary

# 4. Get the Emissary LoadBalancer IP
kubectl get svc emissary-ingress -n emissary \
  -o jsonpath='{.status.loadBalancer.ingress[0].ip}'

# 5. Access the UI
open https://<your-domain>
```

## Uninstalling

```bash
# Remove DevOps Loop Helm release
helm uninstall <prefix>-devops-loop -n devops-loop

# Remove Emissary
helm uninstall emissary-ingress -n emissary
helm uninstall emissary-crds -n emissary

# Destroy all Terraform-managed resources
terraform destroy
```
