##############################################################################
# Provider Configuration
##############################################################################

provider "ibm" {
  ibmcloud_api_key = var.ibmcloud_api_key
  region           = var.region
}

##############################################################################
# Terraform Version Constraints
##############################################################################

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    ibm = {
      source  = "IBM-Cloud/ibm"
      version = ">=1.63.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = ">=2.12.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = ">=2.25.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">=0.9.0"
    }
  }
}
